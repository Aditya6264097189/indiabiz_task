<?php
require_once "db.php";
?>

<div class="account-page">
<div class="account-center">
<div class="account-box">
<?php
if (isset($_GET['id'])){
$id   =   $_GET['id'];

}
?>
<?php
$qry = "select * from user where id='$id'";
$result1 = mysqli_query($db, $qry);
$row1 = mysqli_fetch_array($result1);
$image = $row1['image'];
$prof_path = 'img/'.$image;
$activities = $row1['activities'];
$industries = $row1['industries'];
$location = $row1['location'];
$funding_source = $row1['funding_source'];
$mobile = $row1['mobile'];
$zip = $row1['zip'];
$company_name = $row1['company_name'];
$skills = $row1['skills'];
$id = $row1['id'];
?>

<form action="" method="post"enctype="multipart/form-data">

<h3 style="text-align:center;color:#fff;background-color:darkgreen;margin-top:10px">EDIT PROFILE</h3>

<div class="form-group">
<label>activities</label>
<input type="text" class="form-control" value= "<?php echo $activities ?>" name= "activities" class="form-control form-control-sm">
</div>


<div class="form-group">
<label>industries</label>
<input type="text" class="form-control" value= "<?php echo $industries ?>" name= "industries" class="form-control form-control-sm">

</div>

<div class="form-group">
<label>location</label>
<input type="text" class="form-control" value= "<?php echo $location ?>" name= "location" class="form-control form-control-sm" >
</div> 


<div class="form-group">
<label>Funding Source</label>
<input type="text" class="form-control" value= "<?php echo $funding_source ?>" name= "funding_source" class="form-control form-control-sm" >
</div>


<div class="form-group">
<label>Mobile</label>
<input type="text" class="form-control" value= "<?php echo $mobile ?>" name= "mobile" class="form-control form-control-sm" >
</div> 


<div class="form-group">
<label>Zip</label>
<input type="text" class="form-control" value= "<?php echo $zip ?>" name= "zip" class="form-control form-control-sm" >
</div>


<div class="form-group">
<label>Company Name</label>
<input type="text" class="form-control" value= "<?php echo $company_name ?>" name= "company_name" class="form-control form-control-sm" >
</div>


<div class="form-group">
<label> Skills</label>
<input type="text" class="form-control" value= "<?php echo $skills ?>" name="skills" class="form-control form-control-sm" >
</div>



<div class="form-group">
<table>

<tr><td>preview</td>
<td><a href="img/<?=$image?>" target="_blank"><img src="img/<?=$image?>" width="120px" height="120px"></a></td></tr></table>
<tr>
<td width="20%">Company Logo / Your Image</td>
<td width="60%">
<input type="file" name='image' style="width: 100%" ></td></tr>
</div>



<input type = "submit" style="width: 100%;" name="submit" class=" btn-primary" value="Save">

</form>
</div> 

</div>
</div>

<?php
//update
if (isset($_POST['submit']))
{   
$activities          = trim($_POST['activities']);
$industries   = trim($_POST['industries']);
$location = trim($_POST['location']);
$funding_source = trim($_POST['funding_source']);
$mobile = trim($_POST['mobile']);
$zip = trim($_POST['zip']);
$company_name     =  $_POST['company_name'];
$skills     =  $_POST['skills'];

$qry = "select * from user where id='$id'";
$res = mysqli_query($db,$qry);
$rows =mysqli_fetch_array($res);
$id = $rows['id'];
$image = $rows['image'];

$rand = (rand(10,1000));
$image   = $id.'x'.$rand.'.jpg';

$image2   = $_FILES['image']['name'];
$tempname2 = $_FILES["image"]["tmp_name"];   
$folder = "img/".$image; 
if (move_uploaded_file($tempname2, $folder)) 
{
$msg = "Image uploaded successfully";
mysqli_query($db,"update user set image='$image' where id='$id'");  

}

$qry2 = "UPDATE user SET activities = '$activities', industries = '$industries',location = '$location', funding_source = '$funding_source', mobile = '$mobile', zip = '$zip',company_name = '$company_name',skills = '$skills'
WHERE id = '$id'";
$res=mysqli_query($db,$qry2) or die(mysqli_error($db));
header ("location:view.php");
}
?>