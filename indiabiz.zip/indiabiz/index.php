<?php
require_once "db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/style.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style type="text/css">
.row {
display: -ms-flexbox; /* IE10 */
display: flex;
-ms-flex-wrap: wrap; /* IE10 */
flex-wrap: wrap;
margin: 0 -16px;
}

.col-25 {
-ms-flex: 25%; /* IE10 */
flex: 25%;
}

.col-50 {
-ms-flex: 50%; /* IE10 */
flex: 50%;
}

.col-75 {
-ms-flex: 75%; /* IE10 */
flex: 75%;
}

.col-25,
.col-50,
.col-75 {
padding: 0 16px;
}

.container {
background-color: #f2f2f2;
padding: 5px 20px 15px 20px;
border: 1px solid lightgrey;
border-radius: 3px;
}

input[type=text] {
width: 100%;
margin-bottom: 20px;
padding: 12px;
border: 1px solid #ccc;
border-radius: 3px;
}

label {
margin-bottom: 10px;
display: block;
}

.icon-container {
margin-bottom: 20px;
padding: 7px 0;
font-size: 24px;
}

.btn {
background-color: #04AA6D;
color: white;
padding: 12px;
margin: 10px 0;
border: none;
width: 100%;
border-radius: 3px;
cursor: pointer;
font-size: 17px;
}

.btn:hover {
background-color: #45a049;
}

span.price {
float: right;
color: grey;
}


@media (max-width: 800px) {
.row {
flex-direction: column-reverse;
}
.col-25 {
margin-bottom: 20px;
}
}

.tag {
display: inline-block;
background-color: #333;
color: #fff;
padding: 5px 25px;
margin: 5px;
border-radius: 5px;
cursor:pointer;
}

.selected {
background-color: green;
color: #fff;
}
</style>
</head>
<body>
<div class="main-wrapper account-wrapper">
<div class="account-page">
<div class="account-center">
<div class="account-box">
<div class="row">
<div class="col-75">
<div class="container">
<form method="post" enctype="multipart/form-data">
<div class="row">
<div class="col-75">
<h3 align="center">Form</h3>
<hr>
<label for="fname" style="color: red;">Profile pic</label>
<input type="file" name="file">

<div class="form-check-input">
<label for="email" style="color: red;">Activities:</label>
<input class="form-check-input" type="checkbox" value="Buy" name="activities[]">
<label for="flexCheckDefault">Buy</label>
<input class="form-check-input" type="checkbox" value="Invest" name="activities[]" checked>
<label for="flexCheckChecked">Invest</label>
<input class="form-check-input" type="checkbox" value="Partner" name="activities[]">
<label for="flexCheckChecked">Partner</label>
<input class="form-check-input" type="checkbox" value="Lease" name="activities[]">
<label for="flexCheckChecked">Lease</label>
<input class="form-check-input" type="checkbox" value="Franchise" name="activities[]">
<label for="flexCheckChecked">Franchise</label>
</div>

<label for="industries"style="color: red;">Industries:</label>
<select id="industries" name="industries" class="form-control" required>
<option value="">Select an industry</option>
<option value="Hotel &amp; Restaurent">Hotel &amp; Restaurent</option>
<option value="Banking">Banking</option>
<option value="Information Technology">Information Technology</option>
<option value="Utilities">Utilities</option>
</select>

<label for="location"style="color: red;">Location</label>
<select id="location" name="location" class="form-control" required>
<option value="">Select a location</option>
<option value="Chennai">Chennai</option>
<option value="Delhi">Delhi</option>
<option value="Kolkata">Kolkata</option>
<option value="Mumbai">Mumbai</option>
</select>

<label style="color: red;">Funding Source:</label><br>
<input type="radio" id="funding-own" name="funding_source" value="Own">
<label for="funding-own">Own</label><br>
<input type="radio" id="funding-family" name="funding_source" value="Family &amp; friends">
<label for="funding-family">Family &amp; friends</label><br>
<input type="radio" id="funding-bank" name="funding_source" value="Bank Loan">
<label for="funding-bank">Bank Loan</label><br>
<input type="radio" id="funding-external" name="funding_source" value="External investors">
<label for="funding-external">External investors</label><br>

<div class="row">
<div class="col-50">
<label style="color: red;">Mobile</label>
<input type="text" id="mobile" name="mobile" pattern="[6789][0-9]{9}" title="Please enter a valid phone number" required maxlength="10">
</div>
<div class="col-50">
<label style="color: red;" for="zip">Zip</label>
<input type="text" id="zip" name="zip" maxlength="6" onfocus="mob_chk('mobile')" required>
</div>
</div>

<label style="color: red;" for="cname">Company name</label>
<input type="text" id="cname" name="company_name">

<div id="tagContainer">
<label for="cname" style="color: red;">Skills</label>
<div class="tag" onclick="toggleTag(this)">Marketing</div>
<div class="tag" onclick="toggleTag(this)">Electronics</div>
<div class="tag" onclick="toggleTag(this)">Culinary</div>
</div>

<input type="hidden" id="selectedTags" name="skills" value="">
<input type="text" id="tagInput" placeholder="Enter a new tag">
<button onclick="addTag()" class="btn-primary">Add Tag</button>

</div>
</div>
<input type="submit" value="Submit" name="submit" class="btn">
<a href="view.php"><input type="button" value="View" class="btn"></a>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="sidebar-overlay" data-reff=""></div>

</body>
</html>

<script>
function mob_chk(x) {
var mob = document.getElementById(x);
if (mob.value.length < 10) {
alert("Please enter a 10-digit Mobile No !!!");
mob.focus();
}
}

var selectedTags = [];

function toggleTag(tag) {
tag.classList.toggle("selected");
var tagName = tag.textContent.trim();

if (selectedTags.includes(tagName)) {
selectedTags = selectedTags.filter(function (value) {
return value !== tagName;
});
} else {
selectedTags.push(tagName);
}

document.getElementById("selectedTags").value = selectedTags.join(",");
}

function addTag() {
var input = document.getElementById("tagInput");
var tagName = input.value.trim();

if (tagName !== "") {
var container = document.getElementById("tagContainer");
var newTag = document.createElement("div");
newTag.classList.add("tag", "selected");
newTag.textContent = tagName;
container.appendChild(newTag);
selectedTags.push(tagName);
input.value = "";
document.getElementById("selectedTags").value = selectedTags.join(",");
}
}
</script>

<?php
if (isset($_POST['submit'])) {
$activities = implode(",", $_POST['activities']);
$industries = $_POST['industries'];
$location = $_POST['location'];
$funding_source = $_POST['funding_source'];
$mobile = $_POST['mobile'];
$zip = trim($_POST['zip']);
$company_name = trim($_POST['company_name']);
$skills = $_POST['skills'];

$image = $_FILES['file']['name'];
$tempname = $_FILES["file"]["tmp_name"];

$qry2 = "INSERT INTO user (activities, industries, location, funding_source, mobile, zip, company_name, skills) VALUES ('$activities','$industries','$location','$funding_source','$mobile','$zip','$company_name','$skills')";
$res = mysqli_query($db, $qry2) or die(mysqli_error($db));

if ($res == true) {
$newid = mysqli_insert_id($db);
$image = $newid . '.jpg';
$folder = "img/" . $image;
if (move_uploaded_file($tempname, $folder)) {
$msg = "Image uploaded successfully";
mysqli_query($db, "UPDATE user SET image='$image' WHERE id='$newid'");
// header("location:view.php");
exit;
}
}
}
?>
