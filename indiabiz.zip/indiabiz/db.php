<?php
$my_host = 'localhost';
$my_username = 'root';
$my_pass = '';
$my_db_name = 'indiabiz'; 
$db = mysqli_connect($my_host,$my_username,$my_pass,$my_db_name) or die("cannot connect to server");
?>