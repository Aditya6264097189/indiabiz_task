<?php
include_once('db.php');
?>

<!DOCTYPE html>
<html lang="en">


<!-- profile22:59-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<?php
if(isset($_GET['idx']))
{
$idx = $_GET['idx'];
$sql= "SELECT * FROM user WHERE id= '$idx'";
$result1 = mysqli_query($db, $sql);
$row1 = mysqli_fetch_array($result1);
$image = $row1['image'];
$prof_path = 'img/'.$image;
$activities = $row1['activities'];
$industries = $row1['industries'];
$location = $row1['location'];
$funding_source = $row1['funding_source'];
$mobile = $row1['mobile'];
$zip = $row1['zip'];
$company_name = $row1['company_name'];
$skills = $row1['skills'];
$id = $row1['id'];

}
?>
<body>
<div class="main-wrapper">

<div class="page-wrapper">
<div class="content">
<div class="row">
<div class="col-sm-7 col-6">
<h4 class="page-title">My Profile</h4>
</div>

<div class="col-sm-5 col-6 text-right m-b-30">
<a href="edit_profile.php?id=<?=$id?>" class="btn btn-primary btn-rounded" style="color: white;padding: 10px;"><i class="fa fa-plus"></i> Edit</a>

<a href="delete_profile.php?id=<?=$id?>" class="btn btn-danger btn-rounded" style="color: white;padding: 10px;">Delete</a>
</div>

</div>
<div class="card-box profile-header">
<div class="row">
<div class="col-md-12">
<div class="profile-view">
<div class="profile-img-wrap">
<div class="profile-img">
<img class='avatar' src='<?=$prof_path?>'>
</div>
</div>
<div class="profile-basic">
<div class="row">

<div class="col-md-7">
<ul class="personal-info">
<li>
<span class="title">Mobile:</span>
<span class="text"><a href="#"><?=$mobile?></a></span>
</li>
<li>
<span class="title">Activities:</span>
<span class="text"><a href="#"><?=$activities?></a></span>
</li>
<li>
<span class="title">Industries:</span>
<span class="text"><?=$industries?></span>
</li>
<li>
<span class="title">Location:</span>
<span class="text"><?=$location?></span>
</li>
<li>
<span class="title">Funding Source:</span>
<span class="text"><?=$funding_source?></span>
</li>
<li>
<span class="title">Zip:</span>
<span class="text"><?=$zip?></span>
</li>
<li>
<span class="title">Company Name:</span>
<span class="text"><?=$company_name?></span>
</li>

<li>
<span class="title">Skills:</span>
<span class="text"><?=$skills?></span>
</li>


</ul>
</div>
</div>
</div>
</div>                        
</div>
</div>
</div>

</div>


</div>
</div>

<div class="sidebar-overlay" data-reff=""></div>
<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.slimscroll.js"></script>
<script src="assets/js/app.js"></script>
</body>


<!-- profile23:03-->
</html>