<?php 
require_once "db.php";
?>
<?php
if (isset($_GET['id'])){
$id   =   $_GET['id'];
}
?>
<div class align="center" id="deleteModal" class="modal fade" data-backdrop="static" data-keyboard="false">  
<div class="modal-dialog" role="document">  
<div class="modal-content">
<form method="post">
<div class="modal-header" style="background-color:#F44336;"> 
<h1>Delete!</h1>
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
</div>
<div class="modal-body">
<h1>Are you sure you want to delete this Profile?</h1>

</div> 
<div class="modal-footer">
<input type="hidden" name="id" value="<?php echo $id ?>">
<input  type="submit"class="btn btn-danger" name="update" class="btn btn-danger"value="delete">
<button type="button"  onclick="window.location.href='view.php'" ><i class="fa fa-times" aria-hidden="true"></i> Cancel</button>										
</div>
</form>  
</div>  
</div>  
</div>

<?php
if(isset($_POST['update'])){ 
$id	= $_POST['id'];
$query = "DELETE FROM user WHERE id = $id";
$result = mysqli_query($db, $query)or die(mysqli_error($db));
header('location:view.php');
}	
?>