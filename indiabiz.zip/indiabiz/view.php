<?php
include_once('db.php');
?>

<!DOCTYPE html>
<html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="css/animate.css">

<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/magnific-popup.css">

<link rel="stylesheet" href="css/bootstrap-datepicker.css">
<link rel="stylesheet" href="css/jquery.timepicker.css">

<link rel="stylesheet" href="css/flaticon.css">
<link rel="stylesheet" href="css/style.css">

<body>
<div class='container-fluid'>
<div class="row">


<div class="col-md-8">


<form action='' method="post">
<table align="center" width="70%" border='1' style='font-size:16px'>
<tr class='text-white bg-dark'>
<td  width='5%'>S.no.</td>
<td width='15%'align='center'>Mobile Number</td>
<td width='15%'align='center'>Industries:</td>
<td width='13%'align='center'>View:</td>


</tr>

<?php
$sql = "SELECT * FROM user ORDER BY id DESC";


$sql_run = mysqli_query($db,$sql);
$count = mysqli_num_rows($sql_run);
for($i=1;$i<=$count;$i++)
{
$row = mysqli_fetch_array($sql_run);

$id= $row['id'];
$mobile = $row['mobile'];
$industries = $row['industries'];

?>

<tr>
<td align='center'><?=$i?></td>
<td align='center'><?=$mobile ?></td>
<td align='center'><?=$industries?></td> 

<td align='center' width='13%' ><a href='view_profile.php?idx=<?=$id?>'>View</a></td>

</tr>
<?php              
}
?>
</table>
</form>
</div>
</div>
</div>
</body>
</html>